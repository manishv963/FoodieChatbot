## interactive_story_1
* restaurant_search{"cuisine": "chinese", "location": "mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "mumbai"}
    - utter_ask_price_range
* price_range{"price_range": "more than rs. 700"}
    - slot{"price_range": "more than rs. 700"}
    - action_search_restaurants
    - slot{"location": "mumbai"}
    - utter_ask_emailID
    - utter_ask_emailID
* send_email{"emailID": "rajuv963@gmail.com"}
    - slot{"emailID": "rajuv963@gmail.com"}
    - action_send_email
    - slot{"location": "mumbai"}
    - utter_greet
	- action_chat_restart




## interactive_story_3
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - action_validate_location
    - slot{"location": "Kolkata"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "south indian"}
    - slot{"cuisine": "south indian"}
    - utter_ask_price_range
* price_range{"price_range": "rs. 300 to 700"}
    - slot{"price_range": "rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Kolkata"}
    - utter_ask_emailID
* send_email{"emailID": "manishv963@gmail.com"}
    - slot{"emailID": "manishv963@gmail.com"}
    - action_send_email
    - slot{"location": "Kolkata"}
    - utter_goodbye
	- action_chat_restart


## interactive_story_4
* greet
    - utter_greet
* restaurant_search{"location": "kolkata"}
    - slot{"location": "kolkata"}
    - action_validate_location
    - slot{"location": "Kolkata"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - utter_ask_price_range
* price_range{"price_range": "rs. 300 to 700"}
    - slot{"price_range": "rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Kolkata"}
    - utter_ask_emailID
* send_email{"emailID": "testv963@gmail.com"}
    - slot{"emailID": "testv963@gmail.com"}
    - action_send_email
    - slot{"location": "Kolkata"}
    - utter_goodbye
	- action_chat_restart

## interactive_story_5
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "chandigarh"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "chandigarh"}
    - utter_ask_price_range
* price_range{"price_range": "more than rs. 700"}
    - slot{"price_range": "more than rs. 700"}
    - action_search_restaurants
    - slot{"location": "Chandigarh"}
    - utter_ask_emailID
* send_email{"emailID": "testv963@gmail.com"}
    - slot{"emailID": "testv963@gmail.com"}
    - action_send_email
    - slot{"location": "Chandigarh"}
    - utter_goodbye
	- action_chat_restart

## interactive_story_6
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"cuisine": "chinese", "location": "mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "mumbai"}
    - action_validate_location
    - slot{"location": "Mumbai"}
    - utter_ask_cuisine
* restaurant_search{"cuisine": "north indian"}
    - slot{"cuisine": "north indian"}
    - action_search_restaurants
    - utter_ask_emailID

* send_email{"emailID": "manishv963@gmail.com"}
    - slot{"emailID": "manishv963@gmail.com"}
    - action_send_email
	- action_chat_restart

## interactive_story_7
* greet
    - utter_greet
* restaurant_search
    - utter_ask_location
* restaurant_search{"cuisine": "chinese", "location": "mumbai"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "mumbai"}
    - action_validate_location
    - slot{"location": "Mumbai"}
    - utter_ask_price_range
* price_range{"price_range": "rs. 300 to 700"}
    - slot{"price_range": "rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Mumbai"}
    - utter_ask_emailID
* send_email{"emailID": "testv963@gmail.com"}
    - slot{"emailID": "testv963@gmail.com"}
    - action_send_email
    - slot{"location": "Mumbai"}
    - utter_goodbye
	- action_chat_restart

## interactive_story_8
* greet
    - utter_greet
* restaurant_search{"cuisine": "chinese", "location": "Agra"}
    - slot{"cuisine": "chinese"}
    - slot{"location": "Agra"}
    
    - slot{"location": "Agra"}
    - utter_ask_price_range
* price_range{"price_range": "rs. 300 to 700"}
    - slot{"price_range": "rs. 300 to 700"}
    - action_search_restaurants
    - slot{"location": "Agra"}
    - utter_ask_emailID
* dont_send_email
    - utter_goodbye
    - action_chat_restart


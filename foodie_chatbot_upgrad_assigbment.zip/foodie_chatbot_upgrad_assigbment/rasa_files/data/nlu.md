## intent:affirm
- yes
- yep
- yeah
- indeed
- that's right
- ok
- great
- right, thank you
- correct
- great choice
- sounds really good
- thanks

## intent:goodbye
- bye
- goodbye
- good bye
- stop
- end
- farewell
- Bye bye
- have a good one

## intent:greet
- hey
- howdy
- hey there
- Hola
- hello
- hi
- good morning
- good evening
- dear sir
- Hi
- send it to masn

## intent:send_email
- send all the details on [manish@gmail.com](emailID)
- yes send all the details on  [ahbcdj@dkj.com](emailID)
- Please send it to [ahbcdj@dkj.com](emailID)
- [jddk.2jmd@kdl.co.in](emailID)
- provide all details on [aa@gmail.in](emailID)
- [ahbcdj@gmail.com](emailID)
- yes please send it on [manishv963@gmail.com](emailID)
- send it on [testv963@gmail.com](emailID)
- [testv963@gmail.com](emailID)
- yes send it to [manishv963@gmail.com](emailID)
- yes send it on [manishv963@gmail.com](emailID)
- yes send it to [testv963@gmail.com](emailID)
- send it to [manishv963@gmail.com](emailID)

## intent:dont_send_email
- no dont send it
- no

## intent:price_range
- show me the restaurant in price range between [00 and 5000](price_range)
- good restaurant with price [more than 700](price_range)
- Best restaurant in price range of [500 to 5000](price_range)
- show me the restaurant in bugdet of  [less than 300](price_range)
- [ More than Rs. 700](price_range)
- [Lesser than Rs. 300](price_range)
- [Rs. 300 to 700](price_range)
- [More than Rs. 700](price_range:more than rs. 700)
- [Rs. 300 to 700](price_range:rs. 300 to 700)
- [Rs. 300 to 700](price_range:rs. 300 to 700)

## intent:restaurant_search
- i'm looking for a place to eat
- I’m hungry. Looking out for some good restaurants
- I want to grab lunch
- I am searching for a dinner spot
- Can you suggest some good restaurants in [Pune](location)
- I am looking for some restaurants in [Delhi](location).
- I am looking for some restaurants in [Bangalore](location)
- show me [chinese](cuisine) restaurants
- show me [chines](cuisine:chinese) restaurants in the [New Delhi](location:Delhi)
- show me a [mexican](cuisine) place in the [centre](location)
- i am looking for an [indian](cuisine) spot called olaolaolaolaolaola
- search for restaurants
- i am hungry
- anywhere in the [west](location)
- I am looking for [asian fusion](cuisine) food
- I am looking a restaurant in [294328](location)
- in [Gurgaon](location)
- in [Agra](location)
- [South Indian](cuisine)
- [North Indian](cuisine)
- [Italian](cuisine)
- [Chinese](cuisine:chinese)
- [chinese](cuisine)
- [Lithuania](location)
- Oh, sorry, in [Italy](location)
- in [delhi](location)
- I am looking for some restaurants in [Mumbai](location)
- I am looking for [mexican indian fusion](cuisine)
- please help me to find restaurants in [pune](location)
- Please find me a restaurantin [bangalore](location)
- [mumbai](location)
- show me restaurants
- please find me [chinese](cuisine) restaurant in [delhi](location)
- can you find me a [chinese](cuisine) restaurant
- [delhi](location)
- please find me a restaurant in [ahmedabad](location)
- please show me a few [italian](cuisine) restaurants in [bangalore](location)
- I m hungry. Looking out for some good restaurants
- Im hungry. Looking out for some good restaurants
- [Mumbai](location:mumbai)
- [American](cuisine:american)
- show me the restaurants in [dilli](location)
- [North Indian](cuisine:north indian)
- show me the [chinese](cuisine) restaurants in [delhi](location)
- show me the [chinese](cuisine) restaurant in [mumbai](location)
- Can you suggest some good restaurants in [kolkata](location)
- [South Indian](cuisine:south indian)
- Can you suggest some good restaurants in [Rishikesh](location)
- Okay. Show me some in [agra](location)
- i will prefer [italian](cuisine)
- : Can you suggest some good restaurants in [kolkata](location)
- Im hungry. Looking out for some good [chinese](cuisine) restaurants in [chandigarh](location)
- [chinese](cuisine) restaurant in [mumbai](location)
- [chines](cuisine:chinese) restaurant in [mumbai](location)
- show me some [chinese](cuisine) restaurant in [agraa](location:Agra)
- show me some restaiurant in [rishikesh](location)
- show me some in [pune](location)
- [bengaluru](location:bangalore)
- [chinese](cuisine) restaurant in [madras](location:Chennai)
- in [mumbai](location)
- Can you suggest some good [chinese](cuisine)  restaurants in [Rishikesh](location)
- okays show me some [chinese](cuisine) reataurant in [allahabad](location: Prayagraj)
- show me some good restaurant in [ulhasnagar](location)
- show me some restaurant in [chennai](location)
- [North Indian](cuisine:north indian)

## synonym: Prayagraj
- allahabad
- Allahabad

## synonym:Agra
- agraa
- Agraa

## synonym:Ahmedabad
- ahmadabad
- Ahmadabad

## synonym:Aligarh
- Aligad

## synonym:Amravati
- Amrawati
- Amraoti

## synonym:Amritsar
- Amitsar
- Ramdaspur

## synonym:Aurangabad
- Aurangbad
- Khadki

## synonym:Bareilly
- Barely
- Barelly
- Bareli
- Barelii

## synonym:Belgaum
- Belagavi
- Belgam

## synonym:Bhubaneswar
- Bhubaneshwar
- Bubaneswar
- Bubaneshwar

## synonym:Chandigarh
- Chandigar
- Chandighar

## synonym:Chennai
- madras
- Madras
- chenna

## synonym:Coimbatore
- Kovai
- Coimbator
- Coimbatoor
- Coimbatoore

## synonym:Dehradun
- Deradun
- Dehradoon
- Deradoon

## synonym:Delhi
- New Delhi
- Dilli

## synonym:Faridabad
- Faridabaad

## synonym:Ghaziabad
- Ghaziabaad

## synonym:Gorakhpur
- Gorakhpoor

## synonym:Gulbarga
- Gulbarg

## synonym:Guwahati
- Guahati
- Guwati

## synonym:Hyderabad
- Hyderbad

## synonym:Mysore
- Mysuru

## synonym:Nashik
- Nasik

## synonym:Pondicherry
- Puducherry

## synonym:Pune
- Puna
- poona

## synonym:Vijayawada
- Vijaywada
- Bezawada

## synonym:american
- American
- America
- Americana

## synonym:bangalore
- bengaluru
- Bengaluru

## synonym:chinese
- chines
- Chinese
- Chines

## synonym:kolkata
- Calcutta

## synonym:more than 700
- More than 700

## synonym:more than rs. 700
- More than Rs. 700

## synonym:mumbai
- Mumbai
- Bombay
- Bambai
- Navi Mumbai

## synonym:north indian
- North Indian

## synonym:rs. 300 to 700
- Rs. 300 to 700

## synonym:south indian
- South Indian

## synonym:srinagar
- shrinagar

## synonym:vegetarian
- veggie
- vegg

## regex:emailID
- ^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$

## regex:greet
- hey[^\s]*

## lookup: price_range
- Lesser than Rs. 300
- Rs. 300 to 700
- More than Rs. 700

## lookup: cuisine
- Chinese
- Mexican
- Italian
- American
- South Indian
- North Indian

## lookup: location:
- Ahmedabad
- Bangalore
- Chennai
- Delhi
- Hyderabad
- Kolkata
- Mumbai
- Pune
- Agra
- Ajmer
- Aligarh
- Amravati
- Amritsar
- Asansol
- Aurangabad
- Bareilly
- Belgaum
- Bhavnagar
- Bhiwandi
- Bhopal
- Bhubaneswar
- Bikaner
- Bilaspur
- Bokaro Steel City
- Chandigarh
- Coimbatore
- Cuttack
- Allahabad
- Dehradun
- Dhanbad
- Bhilai
- Durgapur
- Erode
- Faridabad
- Firozabad
- Ghaziabad
- Gorakhpur
- Gulbarga
- Guntur
- Gwalior
- Gurgaon
- Guwahati
- Hamirpur
- Hublia-Dharwad
- Indore
- Jabalpur
- Jaipur
- Jalandhar
- Jammu
- Jamnagar
- Jamshedpur
- Jhansi
- Jodhpur
- Kakinada
- Kannur
- Kanpur
- Kochi
- Kolhapur
- Kollam
- Kozhikode
- Kurnool
- Ludhiana
- Lucknow
- Madurai
- Malappuram
- Mathura
- Goa
- Mangalore
- Meerut
- Moradabad
- Mysore
- Nagpur
- Nanded
- Nashik
- Nellore
- Noida
- Patna
- Pondicherry
- Purulia Prayagraj
- Prayagraj
- Raipur
- Rajkot
- Rajahmundry
- Ranchi
- Rourkela
- Salem
- Sangli
- Shimla
- Siliguri
- Solapur
- Srinagar
- Surat
- Thiruvananthapuram
- Thrissur
- Tiruchirappalli
- Tiruppur
- Ujjain
- Bijapur
- Vadodara
- Varanasi
- Vasai-Virar City
- Vijayawada
- Vijaywada
- Visakhapatnam
- Vellore and Warangal
- Calcutta
- Bombay
- Bambai
- Navi Mumbai
- Chandigar
- Chandighar
- Kovai
- Coimbator
- Coimbatoor
- Coimbatoore
- Deradun
- Dehradoon
- Deradoon
- Faridabaad
- Ghaziabaad
- Gorakhpoor
- Gulbarg
- Guahati
- Guwati
- Mysuru
- Nasik
- Puducherry
- Allahabad
- Vijaywada
- Bezawada
- Agraa
- ahmadabad
- Ahmadabad
- Aligad
- Amrawati
- Amraoti
- Amitsar
- Ramdaspur
- Aurangbad
- Khadki
- Barely
- Barelly
- Bareli
- Barelii
- Belagavi
- Belgam
- Bhubaneshwar
- Bubaneswar
- Bubaneshwar
- Madras
- chenna
- New Delhi
- Dilli
- Hyderbad
- Puna
- poona
- American
- Bengaluru
- chines
- Chinese
- Chines
- AGARTALA
- AIZWAL
- AJMER
- ALLAHABAD
- ALLEPPEY
- ALIBAUG
- ALMORA
- ALSISAR
- ALWAR
- AMBALA
- AMLA
- AMRITSAR
- ANAND
- ANKLESHWAR
- ASHTAMUDI
- AULI
- AURANGABAD
- BADDI
- BADRINATH
- BALASINOR
- BALRAMPUR
- BAMBORA
- BANDHAVGARH
- BANDIPUR
- BARBIL
- BAREILLY
- BEHROR
- BELGAUM
- BERHAMPUR
- BETALGHAT
- BHARATPUR
- BHANDARDARA
- BHARUCH
- BHAVANGADH
- BHAVNAGAR
- BHILAI
- BHIMTAL
- BHOPAL
- BHUBANESHWAR
- BHUJ
- BIKANER
- BINSAR
- BODHGAYA
- BUNDI
- CALICUT
- CANANNORE
- CHAIL
- CHAMBA
- CHANDIGARH
- CHIKMAGALUR
- CHIPLUN
- CHITRAKOOT
- CHITTORGARH
- COIMBATORE
- COONOOR
- COORG
- CUTTACK
- DABHOSA
- DALHOUSIE
- DAMAN
- DANDELI
- DAPOLI
- DARJEELING
- DAUSA
- DEHRADUN
- DHARAMSHALA
- DIBRUGARH
- DIGHA
- DIU
- DIVE AGAR
- DOOARS
- DURGAPUR
- DURSHET
- DWARKA
- GANGOTRI
- GANGTOK
- GANAPATIPULE
- GANDHIDHAM
- GANDHINAGAR
- GARHMUKTESHWAR
- GARHWAL
- GAYA
- GHAZIABAD
- GOA\tGOA
- GOKHARNA
- GONDAL
- GORAKHPUR
- GREATER NOIDA
- GULMARG
- GURGAON
- GURUVAYOOR
- GUWAHATI
- GWALIOR
- HALEBID
- HAMPI
- HANSI
- HARIDWAR
- HASSAN
- HOSPET
- HOSUR
- HUBLI
- HYDERABAD
- IDUKKI
- IGATPURI
- IMPHAL
- INDORE
- JABALPUR
- JAIPUR
- JAISALMER
- JALANDHAR
- JALGAON
- JAMBUGODHA
- JAMMU
- JAMNAGAR
- JAMSHEDPUR
- JAWHAR
- JHANSI
- JODHPUR
- JOJAWAR
- JORHAT
- JUNAGADH
- KABINI
- KALIMPONG
- KANATAL
- KANCHIPURAM
- KANHA
- KANPUR
- KANYAKUMARI
- KARGIL
- KARJAT
- KARNAL
- KARUR
- KARWAR
- KASARGOD
- KASAULI
- KASHIPUR
- KASHID
- KATRA
- KAUSANI
- KAZA
- KAZIRANGA
- KEDARNATH
- KHAJJIAR
- KHAJURAHO
- KHANDALA
- KHIMSAR
- KOCHIN
- KODAIKANAL
- KOLHAPUR
- KOLKATA
- KOLLAM
- KOTA
- KOTAGIRI
- KOTTAYAM
- KOVALAM
- KUFRI
- KUMBALGARH
- KULLU
- KUMARAKOM
- KUMBAKONAM
- KUMILY
- KURSEONG
- KUSHINAGAR
- LEH
- LAKSHADWEEP
- LONAVALA
- LOTHAL
- LUCKNOW
- LUDHIANA
- MADURAI
- MAHABALESHWAR
- MAHABALIPURAM
- MALAPPURAM
- MALPE
- MALSHEJ GHAT
- MALVAN
- MANALI
- MANDAVI
- MANDAWA
- MANESAR
- MARARRI
- MANDORMONI
- MANGALORE
- MANMAD
- MARCHULA
- MATHERAN
- MATHURA
- MCLEODGANJ
- MOHALI
- MOUNT ABU
- MORADABAD
- MORBI
- MUKTESHWAR
- MUMBAI
- MUNDRA
- MUNNAR
- MURUD JANJIRA
- MUSSOORIE
- MYSORE
- NADUKANI
- NAGAPATTINAM
- NAGARHOLE
- NAGAUR FORT
- NAGOTHANE
- NAGPUR
- NAHAN
- NAINITAL
- NALDHERA
- NANDED
- NAPNE
- NASIK
- NAVI MUMBAI
- NERAL
- NILGIRI
- NOIDA
- OOTY
- ORCHHA
- OSIAN
- PACHMARHI
- PALAMPUR
- PALANPUR
- PALI
- PAHALGAM
- PALITANA
- PALLAKAD
- PANCHGANI
- PANCHKULA
- PANNA
- PANHALA
- PANVEL
- PANTNAGAR
- PARWANOO
- PATIALA
- PATHANKOT
- PATNA
- PATNITOP
- PENCH
- PHAGWARA
- PHALODI
- PINJORE
- PONDICHERRY
- POOVAR
- PORBANDAR
- PORT BLAIR
- POSHINA
- PRAGPUR
- PURI
- PUSKHAR
- PUTTAPARTHI
- RAI BAREILLY
- RAICHAK
- RAIPUR
- RAJGIR
- RAJKOT
- RAJPIPLA
- RAJSAMAND
- RAJAHMUNDRY
- RAMESHWARAM
- RAM NAGAR
- RAMGARH
- RANAKPUR
- RANCHI
- RANIKHET
- RANNY
- RANTHAMBORE
- RATNAGIRI
- RAVANGLA
- RISHIKESH
- RISHYAP
- ROHETGARH
- ROURKELA
- SAJAN
- SALEM
- SAPUTARA
- SASAN GIR
- SATTAL
- SAWAI MADHOPUR
- SAWANTWADI
- SECUNDERABAD
- SHILLONG
- SHIMLA
- SHIMLIPAL
- SHIRDI
- SHARAVANBELGOLA
- SHIVANASAMUDRA
- SIANA
- SILIGURI
- SILVASSA
- SIVAGANGA DISTRICT
- SOLAN
- SONAULI
- SRINAGAR
- SUNDERBAN
- SURAT
- TANJORE
- TAPOLA
- TARAPITH
- THANE
- THEKKADY
- THIRVANNAMALAI
- THIRUVANANTHAPURAM
- TIRUCHIRAPALLI
- TIRUPUR
- TIRUPATI
- THRISSUR
- UDAIPUR
- UDHAMPUR
- UDUPI
- UJJAIN
- UTTARKASHI
- VADODARA
- VAGAMON
- VARKALA
- VAPI
- VARANASI
- VELANKANNI
- VELLORE
- VERAVAL
- VIJAYAWADA
- VIKRAMGADH
- VISHAKAPATNAM
- WAYANAD
- WANKANER
- YAMUNOTRI
- YERCAUD
- YUKSOM
- America

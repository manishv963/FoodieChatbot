from __future__ import absolute_import
from __future__ import division
from __future__ import unicode_literals

from rasa_sdk import Action
from rasa_sdk.events import SlotSet
import zomatopy
import json
import smtplib 
from socket import gaierror

def removeNonAscii(s): 
	return "".join(i for i in s if ord(i)<128)

class ActionSearchRestaurants(Action):
	def name(self):
		return 'action_search_restaurants'
		
	def run(self, dispatcher, tracker, domain):
		config={ "user_key":"74264d8a9d3e0a71922356bdc1ec3fe6"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')
		if(cuisine != None):
			cuisine1 = str.lower(cuisine)
			cuisineList =['american','chinese','mexican','italian','north indian','south indian']
			if(cuisine1 not in cuisineList):
				dispatcher.utter_message("Please select another cuisine")
				return [SlotSet('location',loc)] 
		user_price_choice = tracker.get_slot('price_range')
		if(user_price_choice == None):
			user_price_choice = 'NA'
		price_range = 'average cost of two ' +str.lower(user_price_choice)
		if(loc == None):
			dispatcher.utter_message("In what location?")
			return [SlotSet('location',loc)]
		else:
			loc =validateLoc(loc,dispatcher)
			print('city name after validation ', loc)
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		cuisines_dict={'American':1,'bakery':5,'chinese':25,'cafe':30,'italian':55,'biryani':7,'north indian':50,'south indian':85,'Mexican':73}
		results=zomato.restaurant_search(price_range, lat, lon, str(cuisines_dict.get(cuisine)),20)
		print(price_range)
		d = json.loads(results)
		response=""
		if d['results_found'] == 0:
			response= "no results"
		else:
			counter = 0
			for restaurant in d['restaurants']:
				
				if(counter >= 5):
					break
				average_price_for_two = restaurant['restaurant']['average_cost_for_two']
				if(  'less' in user_price_choice and '300' in user_price_choice ):
					
					
					print(counter)
					#print(average_price_for_two)
					if(average_price_for_two <= 300 ):
						counter = counter+1
						response=response+ str(counter)  + '.  '+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+ str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
				elif('700' in user_price_choice and '300' in user_price_choice ):
					
					print(average_price_for_two)

					if(average_price_for_two > 300 and  average_price_for_two <=700):
						counter = counter+1
						response=response + str(counter)  + '.  '+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+ str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
				elif(  'more' in user_price_choice and '700' in user_price_choice ):
					
					print(average_price_for_two)
					if(average_price_for_two > 700 ):
						counter = counter+1
						response=response + str(counter)  + '.  '+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+ str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
				else:
					counter = counter+1
					print(average_price_for_two)

					response= response + str(counter)  + '.  '+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+ str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
				
				
		dispatcher.utter_message("-----"+response)
		print('response from action search ',response)
		return [SlotSet('location',loc),SlotSet('cuisine',tracker.get_slot('cuisine')),SlotSet('price_range',user_price_choice)]

class SendEmail(Action):
	def name(self):
		return 'action_send_email'
	def run(self, dispatcher, tracker, domain):		
		config={ "user_key":"74264d8a9d3e0a71922356bdc1ec3fe6"}
		zomato = zomatopy.initialize_app(config)
		loc = tracker.get_slot('location')
		cuisine = tracker.get_slot('cuisine')

		user_price_choice = tracker.get_slot('price_range')
		print(user_price_choice)
		if(user_price_choice == None):
			user_price_choice = 'NA'
		price_range = 'average cost of two ' +str.lower(user_price_choice)
		location_detail=zomato.get_location(loc, 1)
		d1 = json.loads(location_detail)
		lat=d1["location_suggestions"][0]["latitude"]
		lon=d1["location_suggestions"][0]["longitude"]
		cuisines_dict={'American':1,'bakery':5,'chinese':25,'cafe':30,'italian':55,'biryani':7,'north indian':50,'south indian':85}
		results=zomato.restaurant_search(price_range, lat, lon, str(cuisines_dict.get(cuisine)),20)
		print(price_range)
		d = json.loads(results)
		response=""
		if d['results_found'] == 0:
			response= "no results"
		else:
			counter = 0
			response = "\n"
			for restaurant in d['restaurants']:
				
				if(counter >= 10):
					break
				average_price_for_two = restaurant['restaurant']['average_cost_for_two']
				if(  'less' in user_price_choice and '300' in user_price_choice ):
					
					
					print(counter)
					#print(average_price_for_two)
					if(average_price_for_two <= 300 ):
						counter = counter+1
						response= response + str(counter)  + '.  '+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+ str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
				elif('700' in user_price_choice and '300' in user_price_choice ):
					print(average_price_for_two)
					if(average_price_for_two > 300 and  average_price_for_two <=700):
						counter = counter+1
						response= response + str(counter)  + '.  '+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+ str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
				elif(  'more' in user_price_choice and '700' in user_price_choice ):
					print(average_price_for_two)
					if(average_price_for_two > 700 ):
						counter = counter+1
						response= response + str(counter)  + '.  '+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+ str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
				else:
					print(average_price_for_two)
					counter = counter+1
					response= response + str(counter)  + '.  '+ restaurant['restaurant']['name']+ " in "+ restaurant['restaurant']['location']['address']+" has been rated "+ str(restaurant['restaurant']['user_rating']['aggregate_rating'])+"\n"
				
				# creates SMTP session 
		s = smtplib.SMTP('smtp.gmail.com', 587) 

		# start TLS for security 
		s.starttls() 
		
		print('response from send mail ',response)
		# Authentication 
		username = 'testv963@gmail.com'
		password ='8484943000'
		s.login(username, password) 
		
		# sending the mail 
		receiveremail = tracker.get_slot('emailID')
		if(receiveremail == None):
			dispatcher.utter_message("-----"+"cannot send mail. email address was not specified")
			return [SlotSet('location',None),SlotSet('cuisine',None),SlotSet('price_range',None),SlotSet('price_range',None),SlotSet('emailID',None)]
		print(receiveremail)
		try:
				print(len(response))
				
				response = removeNonAscii(response)
				print('response '+response)
				
				print(s.sendmail(username, receiveremail, response) )
				print(response)
				dispatcher.utter_message("-----"+"Successfully sent email")
				
		except Exception as e:
				print(repr(e))
				dispatcher.utter_message("-----"+"Error: unable to send email")
				
					
				

				# terminating the session 
		s.quit() 				
			#dispatcher.utter_message("-----"+response)
		return []



class ValidateLocation(Action):
	def name(self):
		return 'action_validate_location'
	def run(self, dispatcher, tracker, domain):
		citiesList=['Ahmedabad', 'Bangalore', 'Chennai', 'Delhi', 'Hyderabad', 'Kolkata', 'Mumbai','Pune','Agra', 'Ajmer', 'Aligarh', 'Amravati', 'Amritsar', 'Asansol', 'Aurangabad', 'Bareilly', 'Belgaum', 'Bhavnagar', 'Bhiwandi', 'Bhopal', 'Bhubaneswar', 'Bikaner', 'Bilaspur', 'Bokaro Steel City', 'Chandigarh', 'Coimbatore', 'Cuttack', 'Dehradun', 'Dhanbad', 'Bhilai', 'Durgapur', 'Erode', 'Faridabad', 'Firozabad', 'Ghaziabad', 'Gorakhpur', 'Gulbarga', 'Guntur', 'Gwalior', 'Gurgaon', 'Guwahati', 'Hamirpur', 'Hubli–Dharwad', 'Indore', 'Jabalpur', 'Jaipur', 'Jalandhar', 'Jammu', 'Jamnagar', 'Jamshedpur', 'Jhansi', 'Jodhpur', 'Kakinada', 'Kannur', 'Kanpur', 'Kochi', 'Kolhapur', 'Kollam', 'Kozhikode', 'Kurnool', 'Ludhiana', 'Lucknow', 'Madurai', 'Malappuram', 'Mathura', 'Goa', 'Mangalore', 'Meerut', 'Moradabad', 'Mysore', 'Nagpur', 'Nanded', 'Nashik', 'Nellore', 'Noida', 'Patna', 'Pondicherry', 'Prayagraj', 'Raipur', 'Rajkot', 'Rajahmundry', 'Ranchi', 'Rourkela', 'Salem', 'Sangli', 'Shimla', 'Siliguri', 'Solapur', 'Srinagar', 'Surat', 'Thiruvananthapuram', 'Thrissur', 'Tiruchirappalli', 'Tiruppur', 'Ujjain', 'Bijapur', 'Vadodara', 'Varanasi', 'Vasai-Virar City', 'Vijayawada', 'Visakhapatnam', 'Vellore','Warangal']
		soundexDict ={}
		for city in citiesList:
			code  = get_soundex(city)
			soundexDict[code] = city
		loc = tracker.get_slot('location')
		print('Location from user ',loc)
		if(loc in citiesList):
			return [SlotSet('location',loc)] 
		else:
			loc = tracker.get_slot('location')
			if(loc == None):
				dispatcher.utter_message(' Sorry, we don’t operate in this city. Can you please specify some other location')
				return [SlotSet('location',None),SlotSet('cuisine',None),SlotSet('price_range',None),SlotSet('price_range',None),SlotSet('emailID',None)]
				
			soundexCode = get_soundex(loc)
			soundexCode = get_soundex(loc)
			nameFromCityList  = soundexDict.get(soundexCode) 
			if(nameFromCityList != None):
				return [SlotSet('location',nameFromCityList)] 
			else:
				dispatcher.utter_message(' Sorry, we don’t operate in this city. Can you please specify some other location')
				return [SlotSet('location',None),SlotSet('cuisine',None),SlotSet('price_range',None),SlotSet('price_range',None),SlotSet('emailID',None)]
				
def validateLoc(loc,dispatcher):
		print(loc)
		citiesList=['Ahmedabad', 'Bangalore', 'Chennai', 'Delhi', 'Hyderabad', 'Kolkata', 'Mumbai','Pune','Agra', 'Ajmer', 'Aligarh', 'Amravati', 'Amritsar', 'Asansol', 'Aurangabad', 'Bareilly', 'Belgaum', 'Bhavnagar', 'Bhiwandi', 'Bhopal', 'Bhubaneswar', 'Bikaner', 'Bilaspur', 'Bokaro Steel City', 'Chandigarh', 'Coimbatore', 'Cuttack', 'Dehradun', 'Dhanbad', 'Bhilai', 'Durgapur', 'Erode', 'Faridabad', 'Firozabad', 'Ghaziabad', 'Gorakhpur', 'Gulbarga', 'Guntur', 'Gwalior', 'Gurgaon', 'Guwahati', 'Hamirpur', 'Hubli–Dharwad', 'Indore', 'Jabalpur', 'Jaipur', 'Jalandhar', 'Jammu', 'Jamnagar', 'Jamshedpur', 'Jhansi', 'Jodhpur', 'Kakinada', 'Kannur', 'Kanpur', 'Kochi', 'Kolhapur', 'Kollam', 'Kozhikode', 'Kurnool', 'Ludhiana', 'Lucknow', 'Madurai', 'Malappuram', 'Mathura', 'Goa', 'Mangalore', 'Meerut', 'Moradabad', 'Mysore', 'Nagpur', 'Nanded', 'Nashik', 'Nellore', 'Noida', 'Patna', 'Pondicherry', 'Prayagraj', 'Raipur', 'Rajkot', 'Rajahmundry', 'Ranchi', 'Rourkela', 'Salem', 'Sangli', 'Shimla', 'Siliguri', 'Solapur', 'Srinagar', 'Surat', 'Thiruvananthapuram', 'Thrissur', 'Tiruchirappalli', 'Tiruppur', 'Ujjain', 'Bijapur', 'Vadodara', 'Varanasi', 'Vasai-Virar City', 'Vijayawada', 'Visakhapatnam', 'Vellore','Warangal']
		soundexDict ={}
		for city in citiesList:
			
			code  = get_soundex(city)

			soundexDict[code] = city
		if(loc in citiesList):
			return loc
		else:
			if(loc == None):
				dispatcher.utter_message(' Sorry, we don’t operate in this city. Can you please specify some other location')
				return loc
			soundexCode = get_soundex(loc)
			nameFromCityList  = soundexDict.get(soundexCode) 
			if(nameFromCityList != None):
				return nameFromCityList
			else:
				dispatcher.utter_message(' Sorry, we don’t operate in this city. Can you please specify some other location')
				return loc

def get_soundex(token):
    """Get the soundex code for the string"""
	
    token = token.upper()

    soundex = ""

    # first letter of input is always the first letter of soundex
    soundex += token[0]
    
    # create a dictionary which maps letters to respective soundex codes. Vowels and 'H', 'W' and 'Y' will be represented by '.'
    dictionary = {"BFPV": "1", "CGJKQSXZ":"2", "DT":"3", "L":"4", "MN":"5", "R":"6", "AEIOUHWY":"."}

    for char in token[1:]:
        for key in dictionary.keys():
            if char in key:
                code = dictionary[key]
                if code != soundex[-1]:
                    soundex += code

    # remove vowels and 'H', 'W' and 'Y' from soundex
    soundex = soundex.replace(".", "")
    
    # trim or pad to make soundex a 4-character code
    soundex = soundex[:4].ljust(4, "0")
        
    return soundex



class ActionRestarted(Action):


	def name(self):
		return "action_chat_restart"

	def run(self, dispatcher, tracker, domain):
		return [SlotSet('location',None),SlotSet('cuisine',None),SlotSet('price_range',None),SlotSet('price_range',None),SlotSet('emailID',None)]